package com.adesfe.practica_rv.Adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.adesfe.practica_rv.Ejemplo
import com.adesfe.practica_rv.R

class EjemploAdapter(private val lista:List<Ejemplo>):RecyclerView.Adapter<EjemploViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EjemploViewHolder {

        val layoutInflater = LayoutInflater.from(parent.context)
        return EjemploViewHolder(layoutInflater.inflate(R.layout.itemview,parent,false)) //eliges que vista se utiliza
    }

    override fun onBindViewHolder(holder: EjemploViewHolder, position: Int) {
        val item = lista[position]
        holder.asignarValores(item)
    }

    override fun getItemCount(): Int {
        return lista.size
    }

}