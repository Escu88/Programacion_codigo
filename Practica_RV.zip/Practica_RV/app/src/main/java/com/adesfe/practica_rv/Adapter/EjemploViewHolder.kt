package com.adesfe.practica_rv.Adapter

import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.adesfe.practica_rv.Ejemplo
import com.adesfe.practica_rv.databinding.ItemviewBinding

class EjemploViewHolder(view:View):RecyclerView.ViewHolder(view) {
    private val binding = ItemviewBinding.bind(view)
    fun asignarValores(item: Ejemplo) {
        binding.tv1.text = item.nombre
        binding.tv2.text = item.apellido
        binding.Card.setOnClickListener {
            Toast.makeText(binding.Card.context,"Has pulsado",Toast.LENGTH_SHORT).show()
        }
    }

}