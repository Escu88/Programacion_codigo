package com.adesfe.practica_rv

class Ejemplo(
     var nombre:String,
     var apellido:String
) {



}