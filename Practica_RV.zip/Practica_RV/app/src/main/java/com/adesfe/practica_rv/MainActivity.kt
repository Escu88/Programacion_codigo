package com.adesfe.practica_rv

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Adapter
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.adesfe.practica_rv.Adapter.EjemploAdapter
import com.adesfe.practica_rv.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: EjemploAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(ActivityMainBinding.inflate(layoutInflater).also { binding=it }.root)
        initRecyclerView()
    }


    private fun initRecyclerView() {
        var lista = mutableListOf<Ejemplo>()

        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))
        lista.add(Ejemplo("Michel","Aranda"))

        adapter = EjemploAdapter(lista)

        binding.rv1.layoutManager=LinearLayoutManager(this)
        binding.rv1.adapter = adapter
    }
}