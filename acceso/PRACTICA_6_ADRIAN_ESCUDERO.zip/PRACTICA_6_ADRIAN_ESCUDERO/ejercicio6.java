package TEMA1;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ejercicio6{
	
	public static void main(String[] args) {
	
		try {
			DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document documento = builder.parse(new File("DAM_AD_UD01_P6_GOT_Ini.xml"));
			documento.getDocumentElement().normalize();
			System.out.print("Elemento raiz: "+documento.getDocumentElement().getNodeName());
			NodeList personajes = documento.getElementsByTagName("character");

			for (int i = 0; i < personajes.getLength();i++) {
				Node personaje = personajes.item(i);
			if(personaje.getNodeType() == Node.ELEMENT_NODE) {
				Element e = (Element) personaje;
				NodeList hijos = e.getChildNodes();
				for (int j = 0; j < hijos.getLength();j++) {
					Node hijo = hijos.item(j);
					if (hijo.getNodeType()==Node.ELEMENT_NODE) {
					System.out.print(hijo.getNodeName()+" "+hijo.getTextContent());
					}
					}
			}
		}
	}catch(Exception ex) {
		System.err.println("Error: "+ex.getMessage());
	}
}
}