package TEMA1;
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
public class ejercicio62{
	public static void main(String[] args) {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			//DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document documento = builder.parse(new File("DAM_AD_UD01_P6_GOT_Ini.xml"));

			documento.getDocumentElement().normalize();
			
			System.out.println("---"+documento.getDocumentElement().getNodeName());
			Element root = documento.getDocumentElement();

			Text text = documento.createTextNode("Yo");
			NodeList personajes = documento.getElementsByTagName("character");
			for (int i = 0; i < personajes.getLength();i++) {
				Node personaje = personajes.item(i);
			if(personaje.getNodeType() == Node.ELEMENT_NODE) {
				Element elemento = (Element) personaje;
				
				Element PlayedBy = documento.createElement("PlayedBy");
				Text texto = documento.createTextNode("adrian");
				PlayedBy.appendChild(texto);
				elemento.appendChild(PlayedBy);
				
					System.out.println("--------"+elemento.getElementsByTagName("id").item(0).getNodeName()+
							""+((Element)(elemento.getElementsByTagName("id").item(0))).getAttribute("lang")+
							"\n-------------"+elemento.getElementsByTagName("id").item(0).getTextContent());
					System.out.println("--------"+elemento.getElementsByTagName("name").item(0).getNodeName()
							+"\n-------------"+elemento.getElementsByTagName("name").item(0).getTextContent());
					/*
					System.out.println(elemento.getElementsByTagName("gender").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("gender").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("culture").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("culture").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("born").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("born").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("died").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("died").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("alive").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("alive").item(0).getTextContent());*/
					System.out.println("--------"+elemento.getElementsByTagName("titles").item(0).getNodeName()
							+""+elemento.getElementsByTagName("titles").item(0).getTextContent());
					/*
					if (elemento.getElementsByTagName("aliases").getLength() > 0) {
					System.out.println(elemento.getElementsByTagName("aliases").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("aliases").item(0).getTextContent());}
				
					if (elemento.getElementsByTagName("rialiases").getLength() > 0) {
						System.out.println(elemento.getElementsByTagName("rialiases").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("rialiases").item(0).getTextContent());}

					System.out.println(elemento.getElementsByTagName("father").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("father").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("mother").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("mother").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("spouse").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("spouse").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("allegiances").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("allegiances").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("books").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("books").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("tvSeries").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("tvSeries").item(0).getTextContent());
					*/
			}
		}

}catch(Exception ex) {
		System.err.println("Error: "+ex.getMessage());
	}
}
}