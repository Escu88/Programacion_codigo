package TEMA1;
import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
public class insertar{
	public static void main(String[] args) {
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			//DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			Document documento = builder.parse(new File("DAM_AD_UD01_P6_GOT_Ini.xml"));
			documento.getDocumentElement().normalize();
			System.out.println("---"+documento.getDocumentElement().getNodeName());
			
			NodeList personajes = documento.getElementsByTagName("character");
			
			for (int i = 0; i < personajes.getLength();i++) {
				Node personaje = personajes.item(i);
			if(personaje.getNodeType() == Node.ELEMENT_NODE) {
				
				Element elemento = (Element) personaje;
				Element PlayedBy = documento.createElement("PlayedBy");
				

				
					System.out.println("--------"+elemento.getElementsByTagName("id").item(0).getNodeName()+
							""+((Element)(elemento.getElementsByTagName("id").item(0))).getAttribute("lang")+
							"\n-------------"+elemento.getElementsByTagName("id").item(0).getTextContent());
					

					
					System.out.println("--------"+elemento.getElementsByTagName("name").item(0).getNodeName()
							+"\n-------------"+elemento.getElementsByTagName("name").item(0).getTextContent());
					
					if (elemento.getElementsByTagName("name").item(0).getTextContent().equals("Arya Stark")) {
						Text texto = documento.createTextNode("Alfie Allen");
						PlayedBy.appendChild(texto);
					}else if (elemento.getElementsByTagName("name").item(0).getTextContent().equals("Brandon  Stark")){
						Text texto = documento.createTextNode("Isaac Hempstead-Wright");
						PlayedBy.appendChild(texto);
					}else if (elemento.getElementsByTagName("name").item(0).getTextContent().equals("Rickon Stark")){
						Text texto = documento.createTextNode("Art Parkinson");
						PlayedBy.appendChild(texto);
					}else if (elemento.getElementsByTagName("name").item(0).getTextContent().equals("Robb Stark")){
						Text texto = documento.createTextNode("Richard Madden");
						PlayedBy.appendChild(texto);
					}else if (elemento.getElementsByTagName("name").item(0).getTextContent().equals("Sansa Stark")){
						Text texto = documento.createTextNode("Sophie Turner");
						PlayedBy.appendChild(texto);
					}
					
					elemento.appendChild(PlayedBy);
					
					System.out.println(elemento.getElementsByTagName("gender").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("gender").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("culture").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("culture").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("born").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("born").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("died").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("died").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("alive").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("alive").item(0).getTextContent());
					System.out.println("--------"+elemento.getElementsByTagName("titles").item(0).getNodeName()
							+""+elemento.getElementsByTagName("titles").item(0).getTextContent());
					
					if (elemento.getElementsByTagName("aliases").getLength() > 0) {
					System.out.println(elemento.getElementsByTagName("aliases").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("aliases").item(0).getTextContent());}
				
					if (elemento.getElementsByTagName("rialiases").getLength() > 0) {
						System.out.println(elemento.getElementsByTagName("rialiases").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("rialiases").item(0).getTextContent());}

					System.out.println(elemento.getElementsByTagName("father").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("father").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("mother").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("mother").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("spouse").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("spouse").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("allegiances").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("allegiances").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("books").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("books").item(0).getTextContent());
					System.out.println(elemento.getElementsByTagName("tvSeries").item(0).getNodeName()
							+"-"+elemento.getElementsByTagName("tvSeries").item(0).getTextContent());
					
			}
		}
			
	Element root = documento.createElement("character");
	documento.getDocumentElement().appendChild(root);
	
	Element id = documento.createElement("id");
	Text textid = documento.createTextNode("583");
	root.appendChild(id);
	id.appendChild(textid);
	
	
	Element name = documento.createElement("name");
	Text textnombre = documento.createTextNode("John Snow");
	root.appendChild(name);
	name.appendChild(textnombre);
	
	Element nacido = documento.createElement("nacido");
	Text textnacer = documento.createTextNode("In 283 AC, at Winterfell");
	root.appendChild(nacido);
	nacido.appendChild(textnacer);
	
	Element vivo = documento.createElement("vivo");
	Text textvivo = documento.createTextNode("Falso");
	root.appendChild(vivo);
	vivo.appendChild(textvivo);
	
	Element titulos = documento.createElement("Titulos");
	Element titulo1 = documento.createElement("Titulo1");
	Element titulo2 = documento.createElement("Titulo2");
	Text texttitulo = documento.createTextNode("Lord Commander of the Night's Watch");
	Text texttitulo2 = documento.createTextNode("King in the North");
	root.appendChild(titulos);
	titulos.appendChild(titulo1);
	titulos.appendChild(titulo2);
	titulo1.appendChild(texttitulo);
	titulo2.appendChild(texttitulo2);

	
	Element alias = documento.createElement("alias");
	Element alias1 = documento.createElement("Alias1");
	Element alias2 = documento.createElement("Alias2");
	Element alias3 = documento.createElement("Alias3");
	Element alias4 = documento.createElement("Alias4");
	Element alias5 = documento.createElement("Alias5");
	Element alias6 = documento.createElement("Alias6");
	Element alias7 = documento.createElement("Alias7");
	Element alias8 = documento.createElement("Alias8");

	Text textalias1 = documento.createTextNode("Lord Snow");
	Text textalias2 = documento.createTextNode("Ned Stark's Bastard");
	Text textalias3 = documento.createTextNode("The Snow of Winterfell");
	Text textalias4 = documento.createTextNode("The Crow-Come-Over");
	Text textalias5 = documento.createTextNode("The 998th Lord Commander of the Night's Watch");
	Text textalias6 = documento.createTextNode("The Bastard of Winterfel");
	Text textalias7 = documento.createTextNode("The Black Bastard of the Wall");
	Text textalias8 = documento.createTextNode("Lord Crow");
	
	root.appendChild(alias);
	alias.appendChild(alias1);
	alias.appendChild(alias2);
	alias.appendChild(alias3);
	alias.appendChild(alias4);
	alias.appendChild(alias5);
	alias.appendChild(alias6);
	alias.appendChild(alias7);
	alias.appendChild(alias8);
	
	alias1.appendChild(textalias1);
	alias2.appendChild(textalias2);
	alias3.appendChild(textalias3);
	alias4.appendChild(textalias4);
	alias5.appendChild(textalias5);
	alias6.appendChild(textalias6);
	alias7.appendChild(textalias7);
	alias8.appendChild(textalias8);

	Element libros = documento.createElement("libros");
	Text textlibros = documento.createTextNode("Todos");
	root.appendChild(libros);
	libros.appendChild(textlibros);
	
	Element temporadas = documento.createElement("Temporadas");
	Text texttemp = documento.createTextNode("Todas");
	root.appendChild(temporadas);
	temporadas.appendChild(texttemp);
	
	Element actor = documento.createElement("Actor");
	Text textactor = documento.createTextNode("Kit Harington");
	root.appendChild(actor);
	actor.appendChild(textactor);	
			
			DOMImplementation implementation = builder.getDOMImplementation();
			Document documento2 = implementation.createDocument(null, "GOTOO",  null);
			documento2.setXmlVersion("1.0");	
			Source source = new DOMSource(documento2);
			Result result = new StreamResult(new File("GOT.xml"));
			
		    Node node = documento2.importNode(documento.getDocumentElement(), true);
		    documento2.getDocumentElement().appendChild(node);
		    
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.transform(source,result);

}catch(Exception ex) {
		System.err.println("Error: "+ex.getMessage());
	}
}
}